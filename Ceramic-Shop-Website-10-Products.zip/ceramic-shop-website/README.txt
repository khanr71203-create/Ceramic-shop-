CERAMIC SHOP WEBSITE

index.html = website
images/ = product photos

To add products later: put the new photo in images/, then add another product card in index.html. Upload the changed index.html and the new image to GitHub.
